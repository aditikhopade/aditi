package com.example.demo.entities;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="feedback")
public class FeedbackEntity{
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
	int feedbackid;
	int userid;
	@Column
	String comment;
	int rating;
	public FeedbackEntity() {
		super();
		// TODO Auto-generated constructor stub
	}

	public FeedbackEntity( int userid, String comment, int rating) {
		super();

		this.userid = userid;
		this.comment = comment;
		this.rating = rating;
	}

	public int getFeedbackid() {
		return feedbackid;
	}

	public void setFeedbackid(int feedbackid) {
		this.feedbackid = feedbackid;
	}

	public int getUserid() {
		return userid;
	}

	public void setUserid(int userid) {
		this.userid = userid;
	}

	public String getComment() {
		return comment;
	}

	public void setComment(String comment) {
		this.comment = comment;
	}

	public int getRating() {
		return rating;
	}

	public void setRating(int rating) {
		this.rating = rating;
	}

	
	
	
	
}
