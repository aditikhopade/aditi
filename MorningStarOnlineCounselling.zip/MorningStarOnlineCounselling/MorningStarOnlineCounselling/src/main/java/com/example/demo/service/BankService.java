package com.example.demo.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entities.BankEntity;
import com.example.demo.repositories.BankRepository;



@Service
public class BankService {
	@Autowired
	  BankRepository brepo;
	   public BankEntity add(BankEntity b)
		{
			return brepo.save(b);
		}
}
