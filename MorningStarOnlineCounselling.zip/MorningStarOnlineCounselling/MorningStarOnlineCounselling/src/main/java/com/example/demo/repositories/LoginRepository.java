package com.example.demo.repositories;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import com.example.demo.entities.LoginEntity;

@Repository
public interface LoginRepository extends JpaRepository<LoginEntity, Integer> {
	  
	@Query("Select l from LoginEntity l where l.emailid=?1 and l.password=?2")
	public LoginEntity checkLogin(String emailid,String password);
	
	/*@Query("Update user set password=?1 where userid=?2")
	public String changePassword(int userid,String password);*/

	/*@Query("Select l.id from LoginEntity l where l.emailid=?1 and l.password=?2")
	public int getUserId(String emailid,String password);*/
	

}
