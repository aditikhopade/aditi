package com.example.demo.entities;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="counsellor")
public class CounsellorEntity{
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	int counsellorid;
	@Column
	String specialization;
	int experience;
	int handledcasecount;
	@OneToOne(cascade=CascadeType.ALL)
	@JoinColumn(name="userid")
	LoginEntity userid;
	public CounsellorEntity() {
		super();
		// TODO Auto-generated constructor stub
	}
	public CounsellorEntity(String specialization, int experience, int handledcasecount, LoginEntity userid) {
		super();
		this.specialization = specialization;
		this.experience = experience;
		this.handledcasecount = handledcasecount;
		this.userid = userid;
	}
	public int getCounsellorid() {
		return counsellorid;
	}
	public void setCounsellorid(int counsellorid) {
		this.counsellorid = counsellorid;
	}
	public String getSpecialization() {
		return specialization;
	}
	public void setSpecialization(String specialization) {
		this.specialization = specialization;
	}
	public int getExperience() {
		return experience;
	}
	public void setExperience(int experience) {
		this.experience = experience;
	}
	public int getHandledcasecount() {
		return handledcasecount;
	}
	public void setHandledcasecount(int handledcasecount) {
		this.handledcasecount = handledcasecount;
	}
	public LoginEntity getUserid() {
		return userid;
	}
	public void setUserid(LoginEntity userid) {
		this.userid = userid;
	}
	
}
