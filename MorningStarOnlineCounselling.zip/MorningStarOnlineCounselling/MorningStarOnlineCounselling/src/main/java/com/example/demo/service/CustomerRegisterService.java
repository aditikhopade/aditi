package com.example.demo.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entities.CustomerRegister;
import com.example.demo.entities.LoginEntity;
import com.example.demo.repositories.CustomerRegisterRepository;

@Service
public class CustomerRegisterService {
	   @Autowired
	   CustomerRegisterRepository crepo;
	   public CustomerRegister add(CustomerRegister c)
		{
		   
			return crepo.save(c);
		}
	   public CustomerRegister findByUserid(LoginEntity l)
	   {
		   return crepo.findByUserid(l);
	   }
	   
		public int getById(String emailid,String password)
		{
			return crepo.getById(emailid,password);
		}
}
