package com.example.demo.entities;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
@Entity
@Table(name="customer")
public class CustomerEntitiy {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	int customerid;
	@Column
	String counsellingtype;
	@Column
	String nickname;
	@OneToOne(cascade=CascadeType.ALL)
	@JoinColumn(name="userid")
	LoginEntity userid;
	public CustomerEntitiy() {
		super();
		// TODO Auto-generated constructor stub
	}
	public CustomerEntitiy( String counsellingtype, String nickname, LoginEntity userid) {
		super();
		
		this.counsellingtype = counsellingtype;
		this.nickname = nickname;
		this.userid = userid;
	}
	public int getCustomerid() {
		return customerid;
	}
	public void setCustomerid(int customerid) {
		this.customerid = customerid;
	}
	public String getCounsellingtype() {
		return counsellingtype;
	}
	public void setCounsellingtype(String counsellingtype) {
		this.counsellingtype = counsellingtype;
	}
	public String getNickname() {
		return nickname;
	}
	public void setNickname(String nickname) {
		this.nickname = nickname;
	}
	public LoginEntity getUserid() {
		return userid;
	}
	public void setUserid(LoginEntity userid) {
		this.userid = userid;
	}
	
}
