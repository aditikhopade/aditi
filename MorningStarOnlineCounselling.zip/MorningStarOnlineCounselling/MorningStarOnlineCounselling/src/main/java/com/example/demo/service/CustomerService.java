package com.example.demo.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entities.CustomerEntitiy;
import com.example.demo.entities.LoginEntity;
import com.example.demo.repositories.CustomerRepository;

@Service
public class CustomerService {
   @Autowired
   CustomerRepository crepo;
   public CustomerEntitiy add(CustomerEntitiy c)
	{
	   
		return crepo.save(c);
	}
   public CustomerEntitiy findByUserid(LoginEntity l)
   {
	   return crepo.findByUserid(l);
   }
}
