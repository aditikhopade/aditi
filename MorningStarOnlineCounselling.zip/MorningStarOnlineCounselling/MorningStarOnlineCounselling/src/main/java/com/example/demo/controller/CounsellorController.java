/*package com.example.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entities.CounsellorEntity;
import com.example.demo.entities.CounsellorRegister;


import com.example.demo.entities.LoginEntity;
import com.example.demo.service.CounsellorService;

import com.example.demo.service.LoginService;

@CrossOrigin(origins="http://localhost:3000")
@RestController
public class CounsellorController {
	@Autowired
	  CounsellorService cservice;
	   @Autowired
	  LoginService lservice;
	   LoginEntity inserted;
	  @PostMapping("/registercounsellor")
	  public CounsellorEntity registerCounsellor(@RequestBody CounsellorRegister cr)
	  {
		  LoginEntity l=new LoginEntity(cr.getFname(),cr.getLname(),cr.getEmailid(),cr.getPassword(),cr.getContactno(),cr.getAddress(),cr.getGender(),"counsellor");
		  inserted =lservice.add(l);
		  CounsellorEntity c=new CounsellorEntity(cr.getSpecialization(),cr.getExperience(),cr.getHandledcasecount(),inserted);
		  return cservice.add(c);
		  
	  }
	public LoginEntity checkuseridcounsellor()
	{
		return inserted;
	}
     
}
*/