package com.example.demo.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;

import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entities.CounsellorEntity;
import com.example.demo.entities.CustomerEntitiy;
import com.example.demo.entities.CustomerRegister;
import com.example.demo.entities.LoginEntity;
import com.example.demo.service.CounsellorService;
import com.example.demo.service.CustomerRegisterService;
import com.example.demo.service.CustomerService;
import com.example.demo.service.LoginService;


@CrossOrigin(origins="http://localhost:3000")
@RestController
public class LoginController {
	@Autowired
	LoginService lservice;
	@Autowired
	CustomerService cservice;
	@Autowired
	CounsellorService coservice;
	@Autowired
	CustomerRegisterService custservice;	
	
	@GetMapping("/checkLogin")
	public  CustomerRegister checkLogin(@RequestParam("useremailid") String emailid,@RequestParam("userpassword") String password)
	{
		System.out.println(lservice.checkLogin(emailid,password));
		LoginEntity l=lservice.checkLogin(emailid,password);
	
		System.out.println(l);
		CustomerRegister cr=new CustomerRegister();
		if(l.getType().equals("Customer"))
		{
			CustomerEntitiy c=cservice.findByUserid(l);
			System.out.println(c);
			cr.setAddress(l.getAddress());
			cr.setFname(l.getFname());
			cr.setLname(l.getLname());
			cr.setEmailid(l.getEmailid());
			cr.setPassword(l.getPassword());
			cr.setGender(l.getGender());
			cr.setContactno(l.getContactno());
	        //cr.setUserid(l.getUserid());		
			cr.setType(l.getType());
			cr.setCounsellingtype(c.getCounsellingtype());
			cr.setNickname(c.getNickname());
			cr.setId(custservice.getById(emailid, password));
			
			
		}
		else if(l.getType().equals("Counsellor"))
		{
			CounsellorEntity c=coservice.findByUserid(l);
			System.out.println(c);
			cr.setAddress(l.getAddress());
			cr.setFname(l.getFname());
			cr.setLname(l.getLname());
			cr.setEmailid(l.getEmailid());
			cr.setPassword(l.getPassword());
			cr.setGender(l.getGender());
			cr.setContactno(l.getContactno());
	        //cr.setUserid(l.getUserid());
			cr.setType(l.getType());
			//cr.setType(cr.getUserid());
			cr.setSpecialization(c.getSpecialization());
			cr.setExperience(c.getExperience());
			cr.setHandledcasecount(c.getHandledcasecount());
			cr.setId(custservice.getById(emailid, password));	
			
		}
		else if(l.getEmailid().equals("admin@gmail.com") && l.getPassword().equals("admin@123"))
		{
			cr.setFname(l.getFname());
			cr.setEmailid(l.getEmailid());
			cr.setPassword(l.getPassword());
			cr.setType("Admin");
		}
		else 
		{
		
			return null;
		}
		
	  System.out.println(cr);
		return cr;
	}
	
	
}
