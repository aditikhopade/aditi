package com.example.demo.entities;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="customer_register")
public class CustomerRegister{
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	int id;
	
	@Column
	String fname;
	@Column	
	 String lname;
	@Column
	 String emailid;
	@Column
	 String password;
	@Column
	 String contactno;
	@Column
	 String address;
	@Column
	 String gender;
	@Column
	 String type;
	@Column
	 String counsellingtype;
	@Column
	 String nickname;
	@Column
	 String specialization;
	 int experience;
	 int handledcasecount;
		@OneToOne(cascade=CascadeType.ALL)
		@JoinColumn(name="userid")
		LoginEntity userid;
		
		public CustomerRegister() {
			super();
		
		}

		public CustomerRegister(String fname, String lname, String emailid, String password, String contactno,
				String address, String gender, String type, String counsellingtype, String nickname,
				String specialization, int experience, int handledcasecount, LoginEntity userid) {
			super();
			this.fname = fname;
			this.lname = lname;
			this.emailid = emailid;
			this.password = password;
			this.contactno = contactno;
			this.address = address;
			this.gender = gender;
			this.type = type;
			this.counsellingtype = counsellingtype;
			this.nickname = nickname;
			this.specialization = specialization;
			this.experience = experience;
			this.handledcasecount = handledcasecount;
			this.userid = userid;
		}
		
		public int getId() {
			return id;
		}
		public void setId(int id) {
			this.id = id;
		}
		public String getFname() {
			return fname;
		}
		public void setFname(String fname) {
			this.fname = fname;
		}
		public String getLname() {
			return lname;
		}
		public void setLname(String lname) {
			this.lname = lname;
		}
		public String getEmailid() {
			return emailid;
		}
		public void setEmailid(String emailid) {
			this.emailid = emailid;
		}
		public String getPassword() {
			return password;
		}
		public void setPassword(String password) {
			this.password = password;
		}
		public String getContactno() {
			return contactno;
		}
		public void setContactno(String contactno) {
			this.contactno = contactno;
		}
		public String getAddress() {
			return address;
		}
		public void setAddress(String address) {
			this.address = address;
		}
		public String getGender() {
			return gender;
		}
		public void setGender(String gender) {
			this.gender = gender;
		}
		public String getType() {
			return type;
		}
		public void setType(String type) {
			this.type = type;
		}
		public String getCounsellingtype() {
			return counsellingtype;
		}
		public void setCounsellingtype(String counsellingtype) {
			this.counsellingtype = counsellingtype;
		}
		public String getNickname() {
			return nickname;
		}
		public void setNickname(String nickname) {
			this.nickname = nickname;
		}
		public String getSpecialization() {
			return specialization;
		}
		public void setSpecialization(String specialization) {
			this.specialization = specialization;
		}
		public int getExperience() {
			return experience;
		}
		public void setExperience(int experience) {
			this.experience = experience;
		}
		public int getHandledcasecount() {
			return handledcasecount;
		}
		public void setHandledcasecount(int handledcasecount) {
			this.handledcasecount = handledcasecount;
		}
		public LoginEntity getUserid() {
			return userid;
		}
		public void setUserid(LoginEntity userid) {
			this.userid = userid;
		}


	 
	
	
}