package com.example.demo.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.example.demo.entities.CounsellorEntity;
//import com.example.demo.entities.CustomerEntitiy;
import com.example.demo.entities.LoginEntity;
@Repository
public interface CousellorRepository extends JpaRepository<CounsellorEntity, Integer> {
	
	   @Query("Select c from CounsellorEntity c where c.userid=?1")
	   public CounsellorEntity findByUserid(LoginEntity l);

}
