package com.example.demo.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.example.demo.entities.FeedbackEntity;


import com.example.demo.repositories.FeedbackRepository;
@Service
public class FeedbackService {
	   @Autowired
	  FeedbackRepository frepo;
	   public FeedbackEntity add(FeedbackEntity f)
		{
		   
			return frepo.save(f);
		}

}
