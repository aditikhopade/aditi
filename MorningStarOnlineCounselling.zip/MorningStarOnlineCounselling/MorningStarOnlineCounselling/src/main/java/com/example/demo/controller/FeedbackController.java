package com.example.demo.controller;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import com.example.demo.entities.FeedbackEntity;
import com.example.demo.service.FeedbackService;

@CrossOrigin(origins="http://localhost:3000")
@RestController
public class FeedbackController {
	  @Autowired
	  FeedbackService fservice;
	  
      @PostMapping("/feedbackform")
      public  FeedbackEntity registerFeedback(@RequestBody FeedbackEntity fe)
		{			
		 fservice.add(fe);
         return fe;
		}
}
