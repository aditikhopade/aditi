/*package com.example.demo.entities;
public class CounsellorRegister{
	String fname;
	 String lname;
	 String emailid;
	 String password;
	 String contactno;
	 String address;
	 String gender;
	 String type;
	 String specialization;
	 int experience;
	 int handledcasecount;
	 
	public CounsellorRegister() {
		super();
		// TODO Auto-generated constructor stub
	}

	public CounsellorRegister(String fname, String lname, String emailid, String password, String contactno,
			String address, String gender, String type, String specialization, int experience,
			int handledcasecount) {
		super();
		this.fname = fname;
		this.lname = lname;
		this.emailid = emailid;
		this.password = password;
		this.contactno = contactno;
		this.address = address;
		this.gender = gender;
		
		this.type = type;
		this.specialization = specialization;
		this.experience = experience;
		this.handledcasecount = handledcasecount;
	}

	public String getFname() {
		return fname;
	}

	public void setFname(String fname) {
		this.fname = fname;
	}

	public String getLname() {
		return lname;
	}

	public void setLname(String lname) {
		this.lname = lname;
	}

	public String getEmailid() {
		return emailid;
	}

	public void setEmailid(String emailid) {
		this.emailid = emailid;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getContactno() {
		return contactno;
	}

	public void setContactno(String contactno) {
		this.contactno = contactno;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getSpecialization() {
		return specialization;
	}

	public void setSpecialization(String specialization) {
		this.specialization = specialization;
	}

	public int getExperience() {
		return experience;
	}

	public void setExperience(int experience) {
		this.experience = experience;
	}

	public int getHandledcasecount() {
		return handledcasecount;
	}

	public void setHandledcasecount(int handledcasecount) {
		this.handledcasecount = handledcasecount;
	}
	
}*/