package com.example.demo.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entities.CounsellorEntity;

import com.example.demo.entities.LoginEntity;
import com.example.demo.repositories.CousellorRepository;

@Service
public class CounsellorService {
	@Autowired
	   CousellorRepository crepo;
	   public CounsellorEntity add(CounsellorEntity c)
		{
			return crepo.save(c);
		}
	   public CounsellorEntity findByUserid(LoginEntity l)
	   {
		   return crepo.findByUserid(l);
	   }
}
