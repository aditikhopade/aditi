package com.example.demo.entities;




import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import javax.persistence.Table;

@Entity
@Table(name="bankdetails")
public class BankEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	int bankdetailid;
	int userid;
	@Column
	String useraccno;
	@Column
	String bankname;
	@Column
	String branchname;
	@Column
	String ifsccode;

	public BankEntity() {
		super();

	}

	public BankEntity(int userid, String useraccno, String bankname, String branchname, String ifsccode) {
		super();
		this.userid = userid;
		this.useraccno = useraccno;
		this.bankname = bankname;
		this.branchname = branchname;
		this.ifsccode = ifsccode;
	}

	public int getBankdetailid() {
		return bankdetailid;
	}

	public void setBankdetailid(int bankdetailid) {
		this.bankdetailid = bankdetailid;
	}

	public int getUserid() {
		return userid;
	}

	public void setUserid(int userid) {
		this.userid = userid;
	}

	public String getUseraccno() {
		return useraccno;
	}

	public void setUseraccno(String useraccno) {
		this.useraccno = useraccno;
	}

	public String getBankname() {
		return bankname;
	}

	public void setBankname(String bankname) {
		this.bankname = bankname;
	}

	public String getBranchname() {
		return branchname;
	}

	public void setBranchname(String branchname) {
		this.branchname = branchname;
	}

	public String getIfsccode() {
		return ifsccode;
	}

	public void setIfsccode(String ifsccode) {
		this.ifsccode = ifsccode;
	}



	
	
}
