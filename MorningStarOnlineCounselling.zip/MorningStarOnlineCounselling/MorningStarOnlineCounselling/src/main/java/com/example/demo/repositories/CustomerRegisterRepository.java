package com.example.demo.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.example.demo.entities.CustomerRegister;
import com.example.demo.entities.LoginEntity;

@Repository
public interface CustomerRegisterRepository extends JpaRepository<CustomerRegister, Integer> {
	   @Query("Select c from CustomerRegister c where c.userid=?1")
	   public CustomerRegister findByUserid(LoginEntity l);
	   
		@Query("Select l.id from CustomerRegister l where l.emailid=?1 and l.password=?2")
		public int getById(String emailid,String password);
	  
}
