package com.example.demo.service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.example.demo.entities.LoginEntity;
import com.example.demo.repositories.LoginRepository;

@Service
public class LoginService {
	@Autowired
	LoginRepository lrepo;

	
	public LoginEntity checkLogin(String emailid,String password)
	{
		return lrepo.checkLogin(emailid, password);
	}
	
	public LoginEntity add(LoginEntity l)
	{
		return lrepo.save(l);
	}
 /*	public String changePassword(int userid,String password)
	{
		return lrepo.changePassword(userid,password);
		
	}
     
	public int getUserId(String emailid,String password)
	{
		return lrepo.getUserId(emailid,password);		
	}*/
}
