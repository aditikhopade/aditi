package com.example.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entities.CustomerRegister;
import com.example.demo.entities.LoginEntity;
import com.example.demo.service.CounsellorService;
import com.example.demo.service.CustomerRegisterService;
import com.example.demo.service.CustomerService;
import com.example.demo.service.LoginService;
import com.example.demo.entities.CounsellorEntity;
import com.example.demo.entities.CustomerEntitiy;
@CrossOrigin(origins="http://localhost:3000")
@RestController
//@RequestMapping("/customer")
public class CustomerController {
	
	  @Autowired
	  CustomerService cservice;
	  @Autowired
	  CounsellorService counsel;
	  @Autowired
	  CustomerRegisterService custservice;
	   @Autowired
	  LoginService lservice;
	   LoginEntity inserted;
	   
	  @PostMapping("/registercustomer")
	  public CustomerRegister registerCustomer(@RequestBody CustomerRegister cr)
	  {
		  LoginEntity l=new LoginEntity(cr.getFname(),cr.getLname(),cr.getEmailid(),cr.getPassword(),cr.getContactno(),cr.getAddress(),cr.getGender(),cr.getType());
				  inserted=lservice.add(l);
				  CustomerRegister cust=new CustomerRegister(cr.getFname(),cr.getLname(),cr.getEmailid(),cr.getPassword(),cr.getContactno(),cr.getAddress(),cr.getGender(),cr.getType(),cr.getCounsellingtype(),cr.getNickname(),cr.getSpecialization(),cr.getExperience(),cr.getHandledcasecount(),inserted);
		    custservice.add(cust);
		 if(cr.getType().equals("Customer"))
		  {
			  CustomerEntitiy c=new CustomerEntitiy(cr.getCounsellingtype(),cr.getNickname(),inserted);  
			   cservice.add(c);
		  }
		  else if(cr.getType().equals("Counsellor"))
		  {
			  CounsellorEntity ce=new CounsellorEntity(cr.getSpecialization(),cr.getExperience(),cr.getHandledcasecount(),inserted);
			  counsel.add(ce);
		  }
		return cr;

		
		
	  }
	  public LoginEntity checkuserid()
		{
			return inserted;
		}

}
