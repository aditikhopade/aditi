package com.example.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import com.example.demo.entities.BankEntity;
import com.example.demo.service.BankService;


@CrossOrigin(origins="http://localhost:3000")
@RestController
public class BankController {
	  @Autowired
	  BankService bservice;   
	  
    @PostMapping("/bankregister")
    public  BankEntity registerBank(@RequestBody BankEntity be)
		{		
		 bservice.add(be);
          return be;
		}
}
